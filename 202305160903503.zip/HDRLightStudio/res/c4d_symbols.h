#pragma once
enum
{
	// Plugin
	ID_HDRLS_PLUGIN_NAME				=	0,
	ID_HDRLS_PLUGIN_DESCR				=	4,
	ID_HDRLS_PLUGIN_UPDATES				=	7,
	ID_HDRLS_PLUGIN_URL					=	8,
	ID_HDRLS_PLUGIN_URL_DL				=	9,
	ID_HDRLS_PLUGIN_ERROR				=	11,

	// Standard Dialog Buttons
	ID_HDRLS_FILE						=	18,

	// Errors
	ID_HDRLS_DIALOG_TITLE				=	8193,
	ID_HDRLS_GENERAL					=	8194,
	ID_HDRLS_MEMORY					=	8195,
	ID_HDRLS_DONTSHOWMESSAGE			=	8204,
	// - Notification Levels
	// -- Info
	ID_HDRLS_LEVEL_INFO				=	0,
	// -- Warning
	ID_HDRLS_LEVEL_WARN				=	1,
	// -- Error
	ID_HDRLS_LEVEL_ERROR				=	2,

	// World Preferences
	// - Show message again or not
	ID_HDRLS_WP_SHOWMSG					=	30000,

	// Plugin IDs	
	ID_HDRLIGHTSTUDIOC4D			=	1031132,	// - Command ID
	ID_HDRLS_ENVIRONMENTOBJECT		=	1031133,	// - Object ID
	ID_HDRLS_LIGHTPAINTTOOL			=	1031134,	// - Tool ID
	ID_HDRLS_SCENEHOOK				=	1031135,	// - SceneHook ID
	ID_HDRLS_AREALIGHTTAG			=	1036793,	// - AreaLight Tag ID
	ID_HDRLS_LIVEPANEL				=	10001,		// LivePanel Dialog ID
};
